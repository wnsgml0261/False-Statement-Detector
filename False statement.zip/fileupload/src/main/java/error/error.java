package error;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

public class error {
	
	
	public boolean judge(String urls) 
	{
		
		
			if(urls.contains("https://"))
			{
				return true;
			}
			else {
				return false;
			}
		
    }
	
	public boolean englishError(String url) 
	{
		// call limiError()	
		limitError limit = new limitError();			

		// if user's input is not English then return false
		if(limit.checkInputOnlyNumberAndAlphabet(url) == false){
			return false;
		}
		
		// else return true
		else{
			return true;
			
			}	
		}
	
	public boolean urlError(String url) {
		// call nonsenseError	
		urlError error1 = new urlError();	
			
			// if user type a link that is not a statement, then return false
			if(error1.imageError(url) == false){
				return false;
			}			
		// else return true
			else{
				return true;
				}	
	}

}