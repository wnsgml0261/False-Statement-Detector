package error;

public class limitError {
	public boolean checkInputOnlyNumberAndAlphabet(String input) {
		 
		char chrInput;
		
		 
		for (int i = 0; i < input.length(); i++) { 
			chrInput = input.charAt(i); 
			if ((int)chrInput >= 33 && (int)chrInput <= 126) {
		    
			} 
			else {
				return false;   
			}
		}
		return true;
	}
}
