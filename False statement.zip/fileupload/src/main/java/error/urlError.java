package error;

public class urlError {
	public boolean imageError(String input){
		char chrInput;       // declare variable
	    int count = 0;
	    
	    // checking the user input is typed in number, symbol, and alphabet with in Ascii table.
	    // And return true if the user input is true or return false if the user input is false. 
	    for (int i = 0; i < input.length(); i++) { 
	      chrInput = input.charAt(i); 
	      if ((int)chrInput >= 33 && (int)chrInput <= 126) {
	        count += 1;
	      } 
	    }
	    if(count > 0)
	    {
	      return true;
	    }
	    else{
	      return false;
	    }
		
	}
}
