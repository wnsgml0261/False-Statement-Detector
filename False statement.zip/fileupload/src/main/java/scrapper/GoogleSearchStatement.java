/*package scrapper;


import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.BreakIterator;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import cn.hutool.core.io.file.FileWriter;
import stringSimilarity.similarity;

public class GoogleSearchStatement {
	private static Matcher matcher;
    private static final String DOMAIN_NAME_PATTERN
            = "([a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,15}";
   private static Pattern patrn = Pattern.compile(DOMAIN_NAME_PATTERN);

    public static String getDomainName(String url) {

        String domainName = "";
        matcher = patrn.matcher(url);
        
        if (matcher.find()) {
            domainName = matcher.group(0).toLowerCase().trim();
        }
        
       return domainName;
    }
    public static String remove(String text) {

        //String text = "Our line rackets \rthe encouraged symmetry.\n";
        String cleanString = text.replaceAll("=", "").replaceAll(" ", "");
        
        return cleanString;
       
    }  
	public static final String GOOGLE_SEARCH_URL = "https://www.google.com/search";
	
	
	public static String readFileAsString(String fileName) { 
		String text = ""; 
	try { 
		text = new String(Files.readAllBytes(Paths.get("file.txt"))); 
		} 
	catch (IOException e) 
	{
		e.printStackTrace(); 
	} 
	return text; 
	}

	
	public static boolean main(String origin) throws IOException {
		
		boolean found =false;
		Set<String> result = new HashSet<String>();

		String searchURL = GOOGLE_SEARCH_URL + "?q="+ origin  + "&num=10" ; //search query 
		
		Document doc = Jsoup.connect(searchURL).userAgent("Mozilla/5.0").timeout(5000).get(); //connect to google
		Elements resultLinks = doc.select("a[href]");
		
		String[] strArray=new String[100];
		int i=0;
		for (Element resultLink : resultLinks) {
			
			String linkHref = resultLink.attr("href");
			if(linkHref.startsWith("/url?q=")){
				result.add(getDomainName(linkHref));
				System.out.println( "URL:" + resultLink.attr("href").substring(6, linkHref.indexOf("&")));
				strArray[i]=resultLink.attr("href").substring(6, linkHref.indexOf("&"));}
            
			System.out.printf("i is"+i);
			i=i+1;
		}
		StringBuilder sb = new StringBuilder();
		for(int j=0;j<strArray.length;j++)
		{
			System.out.println("j is "+strArray[j]);
			
			if(strArray[j]!=null)
			{String url=remove(strArray[j]);
				System.out.print("The url is"+url);
				
				Document doc2 = Jsoup.connect(url).get();
				String text = doc2.body().text();
			
                BreakIterator bi = BreakIterator.getSentenceInstance();
				
				bi.setText(text);
			
				int index = 0;
			
				while (bi.next() != BreakIterator.DONE) 
				{
					String sentence = text.substring(index, bi.current());
				    if (similarity.similarity(sentence, origin)>=0.7)
				    {
				    	
				    	found=true;
				    	break;
				    	
				    }
				    
			        index = bi.current();
				}
				
				//if (found==true)
				//{
					break;
				//}
			
					
				
			}
		}
		//System.out.println(sb.toString());
		//System.out.print("The url is"+strArray[0]);
		//Document doc2 = Jsoup.connect(strArray[0]).get();
		//Elements ps = doc.select("p");
		//System.out.print(ps.text());  //it will append all of the p elements together in one long string
		System.out.println("found is"+found);
		return found;
	}
}*/