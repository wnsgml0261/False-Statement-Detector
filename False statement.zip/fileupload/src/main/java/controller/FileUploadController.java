package controller;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import pocr.OCRlocal;
import pocr.OCRmain;
import error.error;
import scrapper.GoogleSearchStatement;
import stringSimilarity.similarity;



@Controller

public class FileUploadController {
    public static String uploadDirectory = System.getProperty("user.dir")+"/uploads";
    public static String url;
    
    @RequestMapping("/")
    public String UploadPage(Model model) {
    	return "uploadview";
    
    }
    @RequestMapping("/upload")
    public String upload(Model model,@RequestParam("files") MultipartFile[] files) throws IOException{
    	StringBuilder fileNames = new StringBuilder();
    	
    	boolean search = false;
    	for(MultipartFile file : files) {
    		Path fileNameAndPath = Paths.get(uploadDirectory,file.getOriginalFilename());
    		
    		
    		fileNames.append(file.getOriginalFilename()+" ");
    		try{
    			Files.write(fileNameAndPath, file.getBytes());
    		}catch (IOException e) {
    			e.printStackTrace();
    		}
    		
    		System.out.println("the fileNameAndPath is "+ fileNameAndPath);
    		
    		OCRlocal local = new OCRlocal();
            String result = local.OCR(fileNameAndPath);
            

          }
    	  
    	  if(search==false) {
        	  return "false";
          }
          else if(search==true){
        	  return "true";
          }
          else {
        	  return "uploadstatusview";
          } 
     	    
    	   
    	}
    
    @RequestMapping("/inputtext")
    public String input(Model model,@RequestParam("fname") String fname) throws IOException{
    	
    	  url=fname;
    	  System.out.println("the URL is "+url);
    	  
    	 error er =new error();
    	 boolean search = false;
    	 
    	 
    	  OCRmain ocr = new OCRmain();
    	  
          String result = ocr.OCR(url);
         
          if(er.englishError(url) == false){
        	  return "errormessage3";
          }
          else if(er.judge(url) == false) {
        	  return "errormessage";
          }
          else { 
              
        	  if(er.urlError(result) == false) {
        	  return "errormessage2";
          }
          else if(search==false) {
        	  return "false";
          }
          else if(search==true){
        	  
        	  return "true";
          }
          else {
        	  return "uploadstatusview";
          }
          
      
    	 
          } 
    	}
    
    
    }
   